#coding:utf-8
# === === Cimetière === === #
    
def creerCimetiere() :
    # Pre-condition : Aucune 
    # Post-condition : Aucune
    # Resultat : Créer un element de Type Cimetière
    
    pass

def entrerCimetiere(cimetiere,carte) :
    # Pre-condition : Le cimetière doit etre celui du joueur qui possède la carte, pas de celui qui attaque
    # Post-condition : Aucune
    # Resultat : La carte est ajoutée au Cimetière. Le cimetiere est donc modifié et renvoyé 
    
    pass